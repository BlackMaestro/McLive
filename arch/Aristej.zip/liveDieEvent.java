package com.bmg.extend.global.event;

import com.bmg.extend.global.skill.anima.animaHelper;
import com.bmg.extend.global.skill.augury.auguryHelper;
import com.bmg.extend.global.skill.butchery.butcheryHelper;
import com.bmg.extend.global.skill.creation.creationSkillHelper;
import com.bmg.extend.global.skill.expedition.expeditionHelper;
import com.bmg.extend.global.skill.extraction.extractionHelper;
import com.bmg.extend.global.skill.foraging.foragingHelper;
import com.bmg.extend.global.skill.hauling.haulingHelper;
import com.bmg.extend.global.skill.hermetism.hermetismHelper;
import com.bmg.extend.global.skill.hunter.hunterHelper;
import com.bmg.extend.global.skill.infusion.infusionHelper;
import com.bmg.extend.global.skill.innervation.innervationHelper;
import com.bmg.extend.global.skill.logging.loggingHelper;
import com.bmg.extend.global.skill.robbery.robberyHelper;
import com.bmg.extend.global.skill.runation.runationHelper;
import com.bmg.extend.global.skill.vulcanism.vulcanismHelper;
import com.bmg.extend.global.tribute.tributeHelper;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.PlayerEvent.PlayerRespawnEvent;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.event.entity.living.LivingDeathEvent;

public class liveDieEvent {

   @SubscribeEvent
   public void onPlayerRespawn(PlayerRespawnEvent evt) {
      NBTTagCompound var10000 = evt.player.getEntityData();
      EntityPlayer var10001 = evt.player;
      NBTTagCompound tag = var10000.getCompoundTag("PlayerPersisted");
      tributeHelper.getProperties(evt.player).setAll();
      hunterHelper props = hunterHelper.getProperties(evt.player);
      props.setLevel(tag.getInteger("HLevel"));
      props.setExperience(tag.getFloat("HExp"));
      creationSkillHelper props2 = creationSkillHelper.getProperties(evt.player);
      props2.setLevel(tag.getInteger("CLevel"));
      props2.setExperience(tag.getFloat("CExp"));
      foragingHelper props3 = foragingHelper.getProperties(evt.player);
      props3.setLevel(tag.getInteger("FLevel"));
      props3.setExperience(tag.getFloat("FExp"));
      auguryHelper props4 = auguryHelper.getProperties(evt.player);
      props4.setLevel(tag.getInteger("ALevel"));
      props4.setExperience(tag.getFloat("AExp"));
      infusionHelper props5 = infusionHelper.getProperties(evt.player);
      props5.setLevel(tag.getInteger("ILevel"));
      props5.setExperience(tag.getFloat("IExp"));
      robberyHelper props6 = robberyHelper.getProperties(evt.player);
      props6.setLevel(tag.getInteger("RoLevel"));
      props6.setExperience(tag.getFloat("RoExp"));
      runationHelper props7 = runationHelper.getProperties(evt.player);
      props7.setLevel(tag.getInteger("RuLevel"));
      props7.setExperience(tag.getFloat("RuExp"));
      innervationHelper props8 = innervationHelper.getProperties(evt.player);
      props8.setLevel(tag.getInteger("InLevel"));
      props8.setExperience(tag.getFloat("InExp"));
      extractionHelper props9 = extractionHelper.getProperties(evt.player);
      props9.setLevel(tag.getInteger("VtLevel"));
      props9.setExperience(tag.getFloat("VtExp"));
      animaHelper props10 = animaHelper.getProperties(evt.player);
      props10.setLevel(tag.getInteger("AnLevel"));
      props10.setExperience(tag.getFloat("AnExp"));
      vulcanismHelper props11 = vulcanismHelper.getProperties(evt.player);
      props11.setLevel(tag.getInteger("VuLevel"));
      props11.setExperience(tag.getFloat("VuExp"));
      expeditionHelper props12 = expeditionHelper.getProperties(evt.player);
      props12.setLevel(tag.getInteger("ExLevel"));
      props12.setBoost(tag.getInteger("ExBoost"));
      props12.setExperience(tag.getFloat("ExExp"));
      butcheryHelper props13 = butcheryHelper.getProperties(evt.player);
      props13.setLevel(tag.getInteger("BuLevel"));
      props13.setExperience(tag.getFloat("BuExp"));
      loggingHelper props14 = loggingHelper.getProperties(evt.player);
      props14.setLevel(tag.getInteger("LoLevel"));
      props14.setExperience(tag.getFloat("LoExp"));
      hermetismHelper props15 = hermetismHelper.getProperties(evt.player);
      props15.setLevel(tag.getInteger("HeLevel"));
      props15.setExperience(tag.getFloat("HeExp"));
      haulingHelper props16 = haulingHelper.getProperties(evt.player);
      props16.setLevel(tag.getInteger("HaLevel"));
      props16.setExperience(tag.getFloat("HaExp"));
      var10000 = evt.player.getEntityData();
      var10001 = evt.player;
      var10000.setTag("PlayerPersisted", tag);
   }

   @SubscribeEvent
   public void onPlayerDeath(LivingDeathEvent evt) {
      if(evt.entity instanceof EntityPlayer) {
         EntityPlayer player = (EntityPlayer)evt.entity;
         hunterHelper props = hunterHelper.getProperties(player);
         NBTTagCompound tag = player.getEntityData().getCompoundTag("PlayerPersisted");
         tag.setFloat("HExp", props.getExperience());
         tag.setInteger("HLevel", props.getLevel());
         creationSkillHelper props2 = creationSkillHelper.getProperties(player);
         tag.setFloat("CExp", props2.getExperience());
         tag.setInteger("CLevel", props2.getLevel());
         foragingHelper props3 = foragingHelper.getProperties(player);
         tag.setFloat("FExp", props3.getExperience());
         tag.setInteger("FLevel", props3.getLevel());
         auguryHelper props4 = auguryHelper.getProperties(player);
         tag.setFloat("AExp", props4.getExperience());
         tag.setInteger("ALevel", props4.getLevel());
         infusionHelper props5 = infusionHelper.getProperties(player);
         tag.setFloat("IExp", props5.getExperience());
         tag.setInteger("ILevel", props5.getLevel());
         player.getEntityData().setTag("PlayerPersisted", tag);
         robberyHelper props6 = robberyHelper.getProperties(player);
         tag.setFloat("RoExp", props6.getExperience());
         tag.setInteger("RoLevel", props6.getLevel());
         player.getEntityData().setTag("PlayerPersisted", tag);
         runationHelper props7 = runationHelper.getProperties(player);
         tag.setFloat("RuExp", props7.getExperience());
         tag.setInteger("RuLevel", props7.getLevel());
         player.getEntityData().setTag("PlayerPersisted", tag);
         innervationHelper props8 = innervationHelper.getProperties(player);
         tag.setFloat("InExp", props8.getExperience());
         tag.setInteger("InLevel", props8.getLevel());
         player.getEntityData().setTag("PlayerPersisted", tag);
         extractionHelper props9 = extractionHelper.getProperties(player);
         tag.setFloat("VtExp", props9.getExperience());
         tag.setInteger("VtLevel", props9.getLevel());
         player.getEntityData().setTag("PlayerPersisted", tag);
         animaHelper props10 = animaHelper.getProperties(player);
         tag.setFloat("AnExp", props10.getExperience());
         tag.setInteger("AnLevel", props10.getLevel());
         player.getEntityData().setTag("PlayerPersisted", tag);
         vulcanismHelper props11 = vulcanismHelper.getProperties(player);
         tag.setFloat("VuExp", props11.getExperience());
         tag.setInteger("VuLevel", props11.getLevel());
         player.getEntityData().setTag("PlayerPersisted", tag);
         expeditionHelper props12 = expeditionHelper.getProperties(player);
         tag.setFloat("ExExp", props12.getExperience());
         tag.setInteger("ExLevel", props12.getLevel());
         tag.setInteger("ExBoost", props12.getBoost());
         player.getEntityData().setTag("PlayerPersisted", tag);
         butcheryHelper props13 = butcheryHelper.getProperties(player);
         tag.setFloat("BuExp", props13.getExperience());
         tag.setInteger("BuLevel", props13.getLevel());
         player.getEntityData().setTag("PlayerPersisted", tag);
         loggingHelper props14 = loggingHelper.getProperties(player);
         tag.setFloat("LoExp", props14.getExperience());
         tag.setInteger("LoLevel", props14.getLevel());
         player.getEntityData().setTag("PlayerPersisted", tag);
         hermetismHelper props15 = hermetismHelper.getProperties(player);
         tag.setFloat("HeExp", props15.getExperience());
         tag.setInteger("HeLevel", props15.getLevel());
         player.getEntityData().setTag("PlayerPersisted", tag);
         haulingHelper props16 = haulingHelper.getProperties(player);
         tag.setFloat("HaExp", props16.getExperience());
         tag.setInteger("HaLevel", props16.getLevel());
         player.getEntityData().setTag("PlayerPersisted", tag);
      }

   }
}
