package com.bmg.extend.global.event;

import java.io.IOException;
import java.util.Random;

import com.bmg.mclive.net.UpdateChecker;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent;
import net.minecraft.entity.player.EntityPlayer;

public class ClientLogin {

   static String message = "Loading...";
   static int pick;
   private static Random rand = new Random();
   static String tip = "Loading...";


   public static String getMsg() {
      return message;
   }

   public static String receiveTip() {
      return tip;
   }

   public static String getTip() {
      pick = rand.nextInt(10);
      return pick == 1?"Use the arrow keys to swap between skill names.":(pick == 2?"Coins can be upgraded through bankers.":(pick == 3?"Incrase tribute bars to receive buffs at night.":(pick == 4?"Good armor and weapons are key to survival.":(pick == 5?"Standing near campfires or life lamps heals you.":(pick == 6?"Battle rage allows you to deal bonus damage.":(pick == 7?"Generic mobs don\'t spawn on building blocks.":(pick == 8?"Use the UP arrow key to toggle expedition types.":(pick == 9?"Use /keepAllInventory to keep items on death.":"Most guns consume metal pellets as ammunition."))))))));
   }


   @SubscribeEvent
   public void onPlayerLogin(PlayerLoggedInEvent e) {
      if(e.player instanceof EntityPlayer) {
         EntityPlayer p = e.player;

         try {
            if(UpdateChecker.isUpdateAvailable()) {
               message = "New version available: (" + UpdateChecker.getCurrentVersion() + ").";
               tip = "You should update .";
            } else {
               message = "No new versions available.";
               tip = getTip();
            }
         } catch (IOException var4) {
            var4.printStackTrace();
         }
      }

   }
}
